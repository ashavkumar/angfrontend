import { Component, OnInit } from '@angular/core';
import { CapbookService } from 'src/app/services/capbook.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  error:string;
  _firstName:string='';
  _lastName:string='';
  _mobileNumber:number;
  _dateOfBirth:Date;
  _gender:string='';
  _emailId:string='';
  _password:string='';

  constructor(private route:ActivatedRoute,private router:Router,private capbookService:CapbookService) { }

  
  get firstName(): string{
    return this._firstName;
  }

  set firstName(value: string){
    this._firstName = value;
  }

  get lastName(): string{
    return this._lastName;
  }

  set lastName(value: string){
    this._lastName = value;
  }
  get mobileNumber(): number{
    return this._mobileNumber;
  }

  set mobileNumber(value: number){
    this._mobileNumber = value;
  }

  get dateOfBirth(): Date{
    return this._dateOfBirth;
  }

  set dateOfBirth(value: Date){
    this._dateOfBirth = value;
  }

  get gender(): string{
    return this._gender;
  }

  set gender(value: string){
    this._gender = value;
  }
  
  get emailId(): string{
    return this._emailId;
  }

  set emailId(value: string){
    this._emailId = value;
  }

  get password(): string{
    return this._password;
  }

  set password(value: string){
    this._password = value;
  }

  ngOnInit() {
  }

  onSubmitClick(){
    const userCredentials:any={
      firstName:this.firstName,
      lastName:this.lastName,
      mobileNumber:this.mobileNumber,
      dateOfBirth:this.dateOfBirth,
      gender:this.gender,
      emaildId:this.emailId,
      password:this.password
    }
  }

}
